/*
 * Authors: Andreja Japundzic
 * Prompt: Classes Assignment: Yer a Wizard!
 * Date Created: Sept. 24, 2020
 * Last Modified: Sept 30, 2020
 * Assumptions: Assumes the user properly formats the .csv file.
 */

package acceptanceprogram;

/**
 *
 * @author Andreja
 */

import java.io.*; //Imported to add File 
import java.util.Scanner; 
import org.apache.commons.io.FilenameUtils; 

public class AcceptanceProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        //Create scanner to catch input
        Scanner sc = new Scanner(System.in);
        
        //String file, holds the file path for the file you want to input into the program.
        String file = "C:/Users/Andreja/Documents/NetBeansProjects/AcceptanceProgram/Magic.csv";
        
        //if the file extension isn't csv then stop the program and request the user to input a different file path to a csv file. FilenameUtls was gotten from the Apache Commons library.
        if(!FilenameUtils.getExtension(file).equals("csv")){
            System.out.println("You inputed the wrong file! This program requiries a .csv file to run properly, please run the program again with a proper file...");
            
            //Exits the program
            System.exit(0);
        }
        
        //Opens up the file
        File myFile = new File(file);
        //Declares scanner to read the file
        Scanner inputFile = new Scanner(myFile);
        
        //menuScreen() method which prints the menu screen
        menuScreen();
        
        //Asks the user for input
        System.out.println("What magical potential does a child need to enter Hogwarts this year?");
        
        //Declares int setMagic and initlizes it with the user input. It holds the magical potential cut off.
        int setMagic = sc.nextInt();
        sc.nextLine();
        
        //newline() method which prints new lines
        newLine();
        
        System.out.println("Letters should be sent to...");
        
        //String temp which stores the current line read by the scanner from the file
        String temp = "";
        
        //Loops until the file has no more lines to read. Scanner reads a line and stores it in temp. Then temp is split into a String array.
        //MaybeStudent class is then initilized with each element of the array and setMagic.
        //The program then prints the String output from the MaybeStudent getter method as long as it isn't null.
        do{
            temp = inputFile.nextLine();
            String arr [] = temp.split(",");
            MaybeStudent student = new MaybeStudent(arr[0], arr[1], arr[2], arr[3], arr[4], setMagic);
            if(!student.getSummary().equals("null")){
                System.out.println(student.getSummary());
            }
        }while(inputFile.hasNextLine());
        
        System.out.println("List Complete! Send the owls!");
        
        //Closes the Scanner used for reading
        inputFile.close();
        
    }//end main
    
    /**
     * Prints out new line characters for spacing.
     */
    private static void newLine(){
        
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        
    }//end newLine
    
    /**
     * Prints out the menu screen and catches user input
     */
    private static void menuScreen(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("                                                                        ____ ");
        System.out.println("                                                                      .'* *.'");
        System.out.println("                                                                   __/_*_*(_");
        System.out.println("                                                                  / _______ \\");
        System.out.println("                                                                 _\\_\\_)/___\\(_/_ ");
        System.out.println("                                                                / _((\\- -/))_ \\");
        System.out.println("                                                                \\ \\())(-)(()/ /");
        System.out.println("                                                                 \' \\(((()))/ \'");
        System.out.println("                                                               / ' \\)).))/ \' \\");
        System.out.println("                                                               / _ \\ - | - /_  \\");
        System.out.println("                                                              (   ( .;\'\'\';. .\'  )");
        System.out.println("                                                              _\\\"__ /    )\\ \"/_");
        System.out.println("                                                                \\/  \\   \' /  \\/");
        System.out.println("                                                                 .\'  \'...\' \' )");
        System.out.println("                                                                  / /  |  \\ \\");
        System.out.println("                                                                 / .   .   . \\");
        System.out.println("                                                                /   .     .   \\");
        System.out.println("                                                               /   /   |   \\   \\");
        System.out.println("                                                             .\'   /    b    \'.  \'.");
        System.out.println("                                                             _.-\'    /     Bb     \'-. \'-._ ");
        System.out.println("                                                         .-\'       |      BBb       \'-.  \'-. ");
        System.out.println("                                                        (________mrf\\____.dBBBb.________)____)\n");
        
        System.out.println(" _    _                                _                                    _                         _____   ");                                  
        System.out.println("| |  | |                              | |           /\\                     | |                       |  __ \\  ");                                  
        System.out.println("| |__| | ___   __ ___      ____ _ _ __| |_ ___     /  \\   ___ ___ ___ _ __ | |_ __ _ _ __   ___ ___  | |__) | __ ___   __ _ _ __ __ _ _ __ ___  ");
        System.out.println("|  __  |/ _ \\ / _` \\ \\ /\\ / / _` | \'__| __/ __|   / /\\ \\ / __/ __/ _ \\ \'_ \\| __/ _` | \'_ \\ / __/ _ \\ |  ___/ \'__/ _ \\ / _` | \'__/ _` | \'_ ` _ \\ ");
        System.out.println("| |  | | (_) | (_| |\\ V  V / (_| | |  | |_\\__ \\  / ____ \\ (_| (_|  __/ |_) | || (_| | | | | (_|  __/ | |   | | | (_) | (_| | | | (_| | | | | | |");
        System.out.println("|_|  |_|\\___/ \\__, | \\_/\\_/ \\__,_|_|   \\__|___/ /_/    \\_\\___\\___\\___| .__/ \\__\\__,_|_| |_|\\___\\___| |_|   |_|  \\___/ \\__, |_|  \\__,_|_| |_| |_|");
        System.out.println("              __/ |                                                 | |                                               __/ |        ");            
        System.out.println("             |___/                                                  |_|                                              |___/    \n");  
        
        System.out.println("Press enter to begin...");
        
        sc.nextLine();
        
        newLine();
        
    }//end mainMenu
    
}//end class AcceptanceProgram
