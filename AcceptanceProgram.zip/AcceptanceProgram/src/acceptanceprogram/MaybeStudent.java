/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acceptanceprogram;

/**
 *
 * @author Andreja
 */

/**
 * The MaybeStudent class takes in student information from a file. If the information meets a certain requirement it is formatted and returned to be printed.
 * @author Andreja
 */

public class MaybeStudent {
    
    private String fullName; //String fullName stores the full name of the student
    private String residence; //String residence stores the residence of the student
    private boolean magical; //boolean magical stores wether or not a student is magical
    private int magicalPotential; //int magicalPotential stores the student's magical potential
    private int magicRequired; //int magicRequired stores the magical potential score the student requires to enter hogwarts
    
    /**
     * Constructor that sets the default values passed as arguments.
     * @param firstName The first name of the student
     * @param lastName The last name of the student
     * @param home The residence of the student
     * @param magicalString Wether or not the student is magical or not
     * @param magicalPotentialString The numerical value of their magical potential
     * @param magicNeeded the magical potential score they need to enter Hogwarts
     */
    public MaybeStudent(String firstName, String LastName, String home, String magicalString, String magicalPotentialString, int magicNeeded){
        //Combines firstName and lastName string and stores it in full name
        fullName = firstName + " " + LastName;
        residence = home;
        
        //If magicalString equals Magical then magical = true
        if(magicalString.equals("Magical")){
            magical = true;
        }
        
        //Converts magicalPotentialString to int and stores it in magicalPotential
        magicalPotential = Integer.parseInt(magicalPotentialString);  
        
        magicRequired = magicNeeded;
    }//end MaybeStudent
    
     /**
     * Returns if the student meets the magical potential requirements or not.
     * @return true or false depending on if they meet the requirement or not
     */
    private boolean accept(){
        boolean accept = false;
        if(magical == true && magicalPotential >= magicRequired){
            accept = true;
        }
        
        return accept;
    }//end accept
    
     /**
     * If accept = true then it formats all the fields into one nice looking String summary to output the information. If accept then it sets sumamry to "null"
     * @return summary
     */
    private String summary(){
        String summary;
        
        if(accept() == true){
            summary = fullName + " in " + residence + ", with a magical potential of " + magicalPotential + "."; 
        }
        else{
            summary = "null";
        }
        
        return summary;
    }//end summary
    
   /**
     * Getter method for summary.
     * @return the summary
     */
 
    public String getSummary(){ 
        return summary(); 
    }//end getSummary
          
}//End class MaybeStudent
