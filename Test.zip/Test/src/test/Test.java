/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
  *assumes corret user input
 */
package test;

/**
 *
 * @author 335216388
 */

import java.util.*;
import java.util.regex.Pattern;
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        menuScreen();
        
        boolean numberCheck = false;
        
        System.out.println("How many numbers do you want to enter?");

        int amountNum = sc.nextInt();
        sc.nextLine();
        
        String arr[] = new String[amountNum];
            
        do{
            System.out.println("Enter " + amountNum + " numbers (Whole or decimal) on one line with a space inbetween each numer.");

            String temp = sc.nextLine();

            String tempArr[] = temp.split(" ");
            
            if((tempArr.length > amountNum) || (tempArr.length < amountNum)){
                System.out.println("Please input the correct amount of numbers...");
                numberCheck = false;
            }
            else{
                for(int i = 0; i < tempArr.length; i++){
                    if (Pattern.matches("[a-zA-Z]+", tempArr[i]) == true){
                        System.out.println("Choose numbers not letters... ");
                        numberCheck = false;
                        break;
                    }
                    else{
                        numberCheck = true;
                        for(int y = 0; y < tempArr.length; y++){
                            arr[y] = tempArr[y];
                        }
                    }
                }
            } 
        }while(numberCheck == false);
        
        Double doubleArr[] = new Double[arr.length];
        
        for(int h = 0; h < arr.length; h++){
            doubleArr[h] = Double.valueOf(arr[h]);
        }
        
        double temp = 0;
        
        for (int i = 0; i < doubleArr.length; i++) {     
            for (int j = i+1; j < doubleArr.length; j++) {     
               if(doubleArr[i] > doubleArr[j]) {    
                   temp = doubleArr[i];    
                   doubleArr[i] = doubleArr[j];    
                   doubleArr[j] = temp;    
               }     
            }     
        }
        
        System.out.println("\nYour numbers sorted from smalles to largest are: ");
        
        for(int i = 0; i < doubleArr.length; i++){
            System.out.print(doubleArr[i] + " ");
        }
        
        System.out.println("\n\nYour smallest number is " + doubleArr[0] + " your largest number is " + doubleArr[amountNum-1] + ".");
        
    }
    
    public static void menuScreen(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("");
        System.out.println(" _   _                 _                  _____            _ ");           
        System.out.println("| \\ | |               | |                / ____|          | |   ");        
        System.out.println("|  \\| |_   _ _ __ ___ | |__   ___ _ __  | (___   ___  _ __| |_ ___ _ __ ");
        System.out.println("| . ` | | | | '_ ` _ \\| '_ \\ / _ \\ '__|  \\___ \\ / _ \\| '__| __/ _ \\ '__|");
        System.out.println("| |\\  | |_| | | | | | | |_) |  __/ |     ____) | (_) | |  | ||  __/ |   ");
        System.out.println("|_| \\_|\\__,_|_| |_| |_|_.__/ \\___|_|    |_____/ \\___/|_|   \\__\\___|_|   ");
        System.out.println("");  
        
        System.out.println("Press enter to start the program...");
        
        sc.nextLine();
        
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                                                                         
    }
    
}
