/**
 * Asks for set of numbers and then organizes the numbers from least to greatest, pointing out the least and greatest number.
 * 
 * Authors: Andreja Japundzic
 * Prompt: Assignment Number 1
 * Date Created: Sept. 18, 2020
 * Last Modified: Sept 22, 2020
  * Assumptions: Assumes the user puts a space in between ever number they input, assumes an int input when asking the user how many numbers they want to enter.
 */
package test;

/**
 *
 * @author 335216388
 */
import java.util.*;
import java.util.regex.Pattern;

public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Create scanner to catch input
        Scanner sc = new Scanner(System.in);
        
        //Calls method menuScreen
        menuScreen();

        //Declares boolean numberCheck and initilzies with false. This boolean is set to true when certain conditions are met, causing the loop to break.
        boolean numberCheck = false;

        //Asks the user for input
        System.out.println("How many numbers do you want to enter?");

        //Declaes int amountNum and initilizes it with the user input
        int amountNum = sc.nextInt();
        sc.nextLine();

        //Declares String arr with the size of amountNum. This array is used to hold the different numbers the user inputs.
        String arr[] = new String[amountNum];

        //do while loop that break when certain conditions are met
        do {
            //Asks the user for input
            System.out.println("Enter " + amountNum + " numbers (whole or decimal) on one line with a space inbetween each number.");
            
            //Creates String temp and initilizes it with user input
            String temp = sc.nextLine();

            //Creates Strin tempArr and initilizes it with the different numbers the user inputs useing the .split method. 
            String tempArr[] = temp.split(" ");
            
            //Checks to see if the user inputed more or less numbers then they said they would, if they did don't break the loop and ask them to input the numbers again.
            //Else, loop through the array and if there are any letters instead of numbers
            if ((tempArr.length > amountNum) || (tempArr.length < amountNum)) {
                System.out.println("Please input the correct amount of numbers. Press enter to continue...");
                sc.nextLine();

                numberCheck = false;
                
                //Calls method newLine
                newLine();
            } else {
                for (int i = 0; i < tempArr.length; i++) {
                    if (Pattern.matches("[a-zA-Z]+", tempArr[i]) == true) {
                        System.out.println("Choose numbers not letters. Press enter to continue... ");

                        sc.nextLine();

                        numberCheck = false;

                        newLine();
                        break;
                    } else {
                        numberCheck = true;
                        for (int y = 0; y < tempArr.length; y++) {
                            arr[y] = tempArr[y];
                        }
                    }
                }
            }
        } while (numberCheck == false);

        Double doubleArr[] = new Double[arr.length];

        for (int h = 0; h < arr.length; h++) {
            doubleArr[h] = Double.valueOf(arr[h]);
        }

        double temp = 0;

        for (int i = 0; i < doubleArr.length; i++) {
            for (int j = i + 1; j < doubleArr.length; j++) {
                if (doubleArr[i] > doubleArr[j]) {
                    temp = doubleArr[i];
                    doubleArr[i] = doubleArr[j];
                    doubleArr[j] = temp;
                }
            }
        }

        System.out.println("\nYour numbers sorted from smallest to largest are: ");

        for (int i = 0; i < doubleArr.length; i++) {
            System.out.print(doubleArr[i] + " ");
        }

        System.out.println("\n\nYour smallest number is " + doubleArr[0] + " your largest number is " + doubleArr[amountNum - 1] + ".");

    }

    public static void menuScreen() {
        Scanner sc = new Scanner(System.in);

        System.out.println("");
        System.out.println(" _   _                 _                  _____            _ ");
        System.out.println("| \\ | |               | |                / ____|          | |   ");
        System.out.println("|  \\| |_   _ _ __ ___ | |__   ___ _ __  | (___   ___  _ __| |_ ___ _ __ ");
        System.out.println("| . ` | | | | '_ ` _ \\| '_ \\ / _ \\ '__|  \\___ \\ / _ \\| '__| __/ _ \\ '__|");
        System.out.println("| |\\  | |_| | | | | | | |_) |  __/ |     ____) | (_) | |  | ||  __/ |   ");
        System.out.println("|_| \\_|\\__,_|_| |_| |_|_.__/ \\___|_|    |_____/ \\___/|_|   \\__\\___|_|   ");
        System.out.println("");

        System.out.println("Press enter to start the program...");

        sc.nextLine();

        newLine();

    }

    public static void newLine() {

        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

    }

}
