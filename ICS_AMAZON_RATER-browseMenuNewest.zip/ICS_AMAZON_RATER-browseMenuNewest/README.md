# ICS_AMAZON_RATER
This is the term long ICS project.

## How this works
This is a book rating database, where you can browse books and get recommendations using our machine learning algorithm.

## Developers
Pranav, Andreja, Jai, Luke
